1. Always choose the correct database.
2. Inputs marked with Important fields must be filled in.